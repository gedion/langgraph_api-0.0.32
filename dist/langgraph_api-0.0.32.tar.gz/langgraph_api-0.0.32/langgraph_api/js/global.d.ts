declare namespace NodeJS {
  interface ProcessEnv {
    LANGSERVE_GRAPHS: string;
    LANGGRAPH_UI?: string;
    PORT: string;
  }
}
